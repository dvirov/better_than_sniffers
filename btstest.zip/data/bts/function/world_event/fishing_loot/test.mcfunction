say detect


















kill @s