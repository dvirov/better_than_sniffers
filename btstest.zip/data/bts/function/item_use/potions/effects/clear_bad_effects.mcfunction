effect clear @s wither
effect clear @s poison
effect clear @s hunger
effect clear @s nausea
effect clear @s blindness
effect clear @s slowness
effect clear @s weakness
effect clear @s mining_fatigue
effect clear @s levitation
effect clear @s bad_omen
effect clear @s darkness
effect clear @s unluck


