$item modify entity @s weapon {"function":"minecraft:set_components","components":{"minecraft:damage":$(value)}}


