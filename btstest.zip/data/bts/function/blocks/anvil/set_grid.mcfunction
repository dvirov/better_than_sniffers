
item replace block ~ ~ ~ container.0 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.1 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.2 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.3 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.4 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.5 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.6 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.7 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.8 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1

item replace block ~ ~ ~ container.9 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.10 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.11 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.12 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.13 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.14 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.15 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.16 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.17 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1

item replace block ~ ~ ~ container.18 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.19 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.20 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.21 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.22 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
#item replace block ~ ~ ~ container.23 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.24 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.25 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1
item replace block ~ ~ ~ container.26 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={anvil:1b}] 1

