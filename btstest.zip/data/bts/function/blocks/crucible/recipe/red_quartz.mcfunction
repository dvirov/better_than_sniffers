execute if score @s crafting.progress matches 10..39 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[1]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 39..59 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[2]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 59..79 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[3]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 79..99 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[4]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 99..119 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[5]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 119..139 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[6]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 139..159 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[7]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 159..189 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[8]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 189..198 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[9]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]
execute if score @s crafting.progress matches 199..200 run item replace block ~ ~ ~ container.26 with barrier[item_model="bts:arrow",custom_model_data={floats:[10]},max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}]

execute unless score @s crafting.progress matches 200 run return run function bts:blocks/crafting_time
scoreboard players set @s crafting.progress 0
item replace block ~ ~ ~ container.26 with barrier[item_model="air",max_stack_size=1,tooltip_display={hide_tooltip:true},custom_data={crucible:1b}] 1
execute if items block ~ ~ ~ container.16 music_disc_11 run item modify block ~ ~ ~ container.16 bts:add1
execute unless items block ~ ~ ~ container.16 music_disc_11 run item replace block ~ ~ ~ container.16 with minecraft:music_disc_11[!minecraft:jukebox_playable,minecraft:max_stack_size=64,minecraft:item_name={"color":"red","text":"Red Quartz"},minecraft:custom_data={"red_quartz":1b,"crucible_made":1b}] 1
item modify block ~ ~ ~ container.10 bts:delete_item
item modify block ~ ~ ~ container.11 bts:delete_item
item modify block ~ ~ ~ container.12 bts:delete_item

#data merge block ~ ~ ~ {CustomName:{"color":"white","text":"\uF807\uF801\uD000"}}