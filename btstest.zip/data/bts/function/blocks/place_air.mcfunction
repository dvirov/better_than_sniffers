setblock ~ ~ ~ air
kill @s
